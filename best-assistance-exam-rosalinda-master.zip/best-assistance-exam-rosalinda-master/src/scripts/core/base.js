window.AppName = window.AppName || {};
window.AppName.Core = window.AppName.Core || {};
window.AppName.Modules = window.AppName.Modules || {};