$(function () {
    AppName.Modules.ThemeModule.init();
});